#!/usr/bin/env python
import time, urllib.request, os
user = "pontus"
host = "lgss.se"
dest = "/srv/http/projekt/dokument/" + user
local = "/home/" + user + "/Drop/"
localsync = "/home/" + user + "/.sync"


while(1):
	LastUpdate = urllib.request.urlopen("http://xn--mlnet-mra.se/dokument/" + user + ".sync").read()
	LocalUpdate = open(localsync, "r").read()
	if(int(LocalUpdate)<int(LastUpdate)):
		os.system('rsync  -a --delete -e "ssh -p 8080" ' + user + '@' + host + ':' + dest + '/ ' + local + '/')
		os.system('scp -P 8080 ' + user + '@'+ host + ':' + dest + '.sync' + ' ' + localsync)
	time.sleep(10)
