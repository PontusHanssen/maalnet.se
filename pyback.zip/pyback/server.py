#!/usr/bin/env python
import pyinotify, os

user = "simon"
source = "/srv/http/projekt/dokument/" + user

wm = pyinotify.WatchManager()

mask = pyinotify.IN_DELETE | pyinotify.IN_CREATE | pyinotify.IN_MOVED_TO | pyinotify.IN_MOVED_FROM | pyinotify.IN_MODIFY

class EventHandler(pyinotify.ProcessEvent):
	def process_IN_CREATE(self, event):
		sync()
	def process_IN_MODIFY(self, event):
		sync()
	def process_IN_DELETE(self, event):
		sync()
	def process_IN_MOVED_TO(self, event):
			sync()
handler = EventHandler()
notifier = pyinotify.Notifier(wm, handler)

wm.add_watch(source, mask, rec=True)

def sync():
	wm.add_watch(source, mask, rec=True)
	os.system('echo $(date +%s) > ' + source + '.sync')
	print("Hej.")
notifier.loop()
