#!/usr/bin/env python
# -*- coding: utf-8 -*-
import pyinotify, os
user = "pontus"
host = "lgss.se"
dest = "/srv/http/projekt/dokument/" + user + "/"
local = "/home/" + user + "/Drop/"

wm = pyinotify.WatchManager()



#Vad ska vi leta efter?
mask = pyinotify.IN_DELETE | pyinotify.IN_CREATE | pyinotify.IN_MOVED_TO | pyinotify.IN_MOVED_FROM | pyinotify.IN_MODIFY

class EventHandler(pyinotify.ProcessEvent):
	def process_IN_CREATE(self, event):
		copy(event.pathname)
		wdd = wm.add_watch(local, mask, rec=True)
	def process_IN_MODIFY(self, event):
		copy(event.pathname)
	def process_IN_DELETE(self, event):
		remove(event.pathname)
	def process_IN_MOVED_TO(self, event):
		if event.src_pathname:
			#Flyttar en fil.
			move(event.src_pathname, event.pathname)
		else:
			#en fil flyttades till drop mappen men vi vet inte var den kommer ifrån. Lägger bara till filen.
			copy(event.pathname)
handler = EventHandler()
notifier = pyinotify.Notifier(wm, handler)

#lägg till mappen vi vill hålla koll på, filtrera vilka events vi ska leta efter med mask variabeln.
wdd = wm.add_watch(local, mask, rec=True)



#funktion för att kopiera fil till servern
def copy(n):
	os.system('scp -r -P 8080 "' + n + '" ' + user + '@' + host + ':"\'' + dest + '$(echo ' + n.replace(" ", "\\ ") + ' | cut -d/ -f5)\'"')
	os.system('ssh -p 8080 ' + user + '@' + host + ' "chmod -R 777  "' + dest.replace(" ", "\\ ") + '$(echo ' + n.replace(" ", "\\ ") + ' | cut -d/ -f5)""')
	
#funktion för att ta bort fil på servern
def remove(n):
	os.system('ssh -p 8080 ' + user + '@' + host + ' "rm -rf ' + dest.replace(" ", "\\ ") + '$(echo ' + n.replace(" ", "\\\ ") + ' | cut -d/ -f5-)"')
	print('ssh -p 8080 ' + user + '@' + host + ' "rm -rf ' + dest.replace(" ", "\\ ") + '$(echo ' + n.replace(" ", "\\ ") + ' | cut -d/ -f5-)"')

#funktion för att flyta fil
def move(a, b):
	os.system('ssh ' + user + '@' + host + ' -p 8080 "mv ' + dest.replace(" ", "\\\ ") + '$(echo ' + a.replace(" ", "\\\ ") + ' |     cut -d/ -f5-) ' + dest.replace(" ", "\\\ ") + '$(echo ' + b.replace(" ", "\\\ ") + ' | cut -d/ -f5-)"') 
#loopa eländet tills vi stänger av programmet.
notifier.loop()
